# Circle Marketplace Demo

**What you got**

- Node.js + Express demo server (server-side rendered with EJS).
- PostgreSQL init SQL at `sql/init.sql` (database name `bank_italia`).
- Simple demo flows: Partner posts service, Builder browses services and requests a service, ledger HOLD created, Partner accepts and delivers, HOLD -> DEDUCT transfer, Builder leaves review.

**Setup**

1. Install Node.js (v18+ recommended) and PostgreSQL.
2. Create database `bank_italia`:
   - `createdb -U postgres bank_italia` (or use pgAdmin)
   - password for postgres user should be `12345` (as you requested) or adjust `DATABASE_URL` in `.env`.
3. Run SQL init:
   - `psql -U postgres -d bank_italia -f sql/init.sql`
4. Install Node deps:
   - `npm install`
5. Copy `.env.example` to `.env` and adjust if needed.
6. Start server:
   - `npm start`
7. Open `http://localhost:3000`

**Notes**

- This is a demo with server-rendered pages (no SPA). It connects to Postgres and performs the flows.
- For production: add authentication, input validation, CSRF protection, and run behind HTTPS.
