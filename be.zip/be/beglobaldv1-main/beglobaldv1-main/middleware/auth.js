import dotenv from "dotenv";

dotenv.config();

const userInjectionMiddleware = (req, res, next) => {
  const circleEmail = req.query.circleEmail;
  const circleName = req.query.circleName;

  req.user = circleEmail
    ? { email: circleEmail, name: circleName || "Circle User" }
    : {
        email: process.env.CIRCLE_AUTH_EMAIL,
        name: "Circle User (DEV)",
      };

  next();
};

export { userInjectionMiddleware };
