import cors from "cors";

const corsMiddleware = cors({
  origin: "*",
});

const cspMiddleware = (req, res, next) => {
  res.removeHeader("X-Frame-Options");
  res.setHeader(
    "Content-Security-Policy",
    "frame-ancestors 'self' https://app.circle.so https://*.circle.so https://community.beeglobal.co https://*.beeglobal.co;"
  );
  next();
};

export { corsMiddleware, cspMiddleware };
