import pool from "../config/database.js";

async function findUserByEmail(email) {
  if (!email) return null;
  const q = `select * from app_user where email = $1 limit 1`;
  const r = await pool.query(q, [email.toLowerCase()]);
  return r.rows[0] || null;
}

async function createUser({ email, full_name = "", role = "BUILDER" }) {
  const q = `insert into app_user (email, full_name, role) values ($1,$2,$3) returning *`;
  const r = await pool.query(q, [email.toLowerCase(), full_name, role]);
  // create wallet row as well if missing
  const { ensureWallet } = await import("./wallet.js");
  await ensureWallet(r.rows[0].id);
  return r.rows[0];
}

async function findOrCreateUser({ email, full_name = "", role = "BUILDER" }) {
  if (!email) throw new Error("email required");
  const existing = await findUserByEmail(email);
  if (existing) return existing;
  return createUser({ email, full_name, role });
}

export { findUserByEmail, createUser, findOrCreateUser };
