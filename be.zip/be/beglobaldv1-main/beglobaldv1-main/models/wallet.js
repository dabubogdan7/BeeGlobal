import pool from "../config/database.js";
import { v4 as uuidv4 } from "uuid";

async function ensureWallet(user_id) {
  if (!user_id) return;
  const q = `insert into wallet (user_id, balance, hold_balance)
             values ($1,0,0)
             on conflict (user_id) do nothing`;
  await pool.query(q, [user_id]);
}

async function createLedgerEntry(
  client,
  { request_id = null, user_id, type, amount }
) {
  const q = `insert into ledger_entry (id, request_id, user_id, type, amount)
             values ($1,$2,$3,$4,$5) returning *`;
  const id = uuidv4();
  const r = await client.query(q, [id, request_id, user_id, type, amount]);
  return r.rows[0];
}

// move funds into hold: builder pays -> balance -= amount, hold_balance += amount
async function holdFromBuilder(client, builder_id, amount) {
  // ensure wallet exists
  await client.query(
    `insert into wallet (user_id,balance,hold_balance)
                      values ($1,0,0)
                      on conflict (user_id) do nothing`,
    [builder_id]
  );

  const q = `update wallet
             set balance = balance - $1,
                 hold_balance = hold_balance + $1
             where user_id = $2
             returning *`;
  const r = await client.query(q, [amount, builder_id]);
  if (r.rowCount === 0) {
    throw new Error("Builder wallet update failed");
  }
  return r.rows[0];
}

// transfer from builder hold to partner balance (on deliver)
async function transferHoldToPartner(
  client,
  builder_id,
  partner_id,
  amount,
  request_id = null
) {
  // reduce builder hold
  const q1 = `update wallet
              set hold_balance = hold_balance - $1
              where user_id = $2
              returning *`;
  const r1 = await client.query(q1, [amount, builder_id]);
  if (r1.rowCount === 0) throw new Error("builder hold update failed");

  // credit partner balance
  const q2 = `insert into wallet (user_id,balance,hold_balance)
              values ($1, $2, 0)
              on conflict (user_id) do update set balance = wallet.balance + $2
              returning *`;
  const r2 = await client.query(q2, [partner_id, amount]);

  // ledger entries
  await createLedgerEntry(client, {
    request_id,
    user_id: builder_id,
    type: "DEDUCT",
    amount,
  });
  await createLedgerEntry(client, {
    request_id,
    user_id: partner_id,
    type: "CREDIT",
    amount,
  });

  return { builder: r1.rows[0], partner: r2.rows[0] };
}

// release hold back to builder (e.g., on cancel)
async function releaseHoldToBuilder(
  client,
  builder_id,
  amount,
  request_id = null
) {
  // decrease hold_balance and increase balance
  const q = `update wallet
             set hold_balance = hold_balance - $1,
                 balance = balance + $1
             where user_id = $2
             returning *`;
  const r = await client.query(q, [amount, builder_id]);
  if (r.rowCount === 0) throw new Error("release hold failed");
  // ledger
  await createLedgerEntry(client, {
    request_id,
    user_id: builder_id,
    type: "RELEASE",
    amount,
  });
  return r.rows[0];
}

export {
  ensureWallet,
  createLedgerEntry,
  holdFromBuilder,
  transferHoldToPartner,
  releaseHoldToBuilder,
};
