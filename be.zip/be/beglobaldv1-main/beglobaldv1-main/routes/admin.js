import { Router } from "express";
import pool from "../config/database.js";

const router = Router();

// admin page (shows wallets + quick admin actions)
router.get("/admin", async (req, res) => {
  try {
    const walletsRes = await pool.query(
      `select w.*, u.full_name as primary_builder_name, u.email as primary_builder_email, u.id as team_id
       from wallet w
       left join app_user u on u.id = w.user_id
       order by w.user_id`
    );
    const wallets = walletsRes.rows || [];
    res.render("admin", { wallets });
  } catch (err) {
    console.error("admin err:", err);
    res.status(500).send("Server error");
  }
});

// Admin: adjust wallet (POST)
router.post("/admin/wallet/:teamId/adjust", async (req, res) => {
  const teamId = req.params.teamId;
  const { balance, hold } = req.body;
  try {
    await pool.query(
      `insert into wallet (user_id,balance,hold_balance)
                      values ($1,$2,$3)
                      on conflict (user_id) do update set balance = $2, hold_balance = $3`,
      [teamId, Number(balance || 0), Number(hold || 0)]
    );
    res.redirect("/admin");
  } catch (err) {
    console.error("wallet adjust err:", err);
    res.status(500).send("Server error");
  }
});

// Admin: update request status quickly
router.post("/admin/request/:id/status", async (req, res) => {
  const id = req.params.id;
  const { status } = req.body;
  try {
    await pool.query(`update service_request set status = $1 where id = $2`, [
      status,
      id,
    ]);
    res.redirect("/admin");
  } catch (err) {
    console.error("admin set status err:", err);
    res.status(500).send("Server error");
  }
});

// Admin: edit service
router.post("/admin/service/:id/edit", async (req, res) => {
  const id = req.params.id;
  const { title, price, status } = req.body;
  try {
    await pool.query(
      `update service set title=$1, price=$2, status=$3 where id=$4`,
      [title, Number(price || 0), status || "ACTIVE", id]
    );
    res.redirect("/admin");
  } catch (err) {
    console.error("admin edit service err:", err);
    res.status(500).send("Server error");
  }
});

export default router;
