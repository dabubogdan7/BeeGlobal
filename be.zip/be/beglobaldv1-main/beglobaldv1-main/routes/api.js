import { Router } from "express";
import pool from "../config/database.js";
import { findUserByEmail, createUser } from "../models/user.js";

const router = Router();

// Get user role by email
router.get("/api/user-role", async (req, res) => {
  const email = req.query.email;
  if (!email) return res.status(400).json({ error: "email required" });

  try {
    const user = await findUserByEmail(email);
    if (user) {
      res.json({ role: user.role || "BUILDER" });
    } else {
      res.json({ role: "BUILDER" }); // Default role for non-existent users
    }
  } catch (err) {
    console.error("api user-role err", err);
    res.status(500).json({ error: String(err) });
  }
});

// Simple services API
router.get("/api/services", async (req, res) => {
  try {
    const r =
      await pool.query(`select s.*, u.full_name as partner_name, u.email as partner_email
                                from service s join app_user u on u.id = s.partner_id
                                order by s.created_at desc`);
    res.json(r.rows);
  } catch (err) {
    console.error("api services err", err);
    res.status(500).json({ error: String(err) });
  }
});

router.post("/api/services", async (req, res) => {
  const { partner_email, title, description, price } = req.body;
  if (!partner_email || !title)
    return res.status(400).json({ error: "missing fields" });

  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    let partner = await findUserByEmail(partner_email);
    if (!partner)
      partner = await createUser({
        email: partner_email,
        full_name: "",
        role: "PARTNER",
      });
    await client.query(
      `insert into service (partner_id, title, description, price, status) values ($1,$2,$3,$4,'ACTIVE')`,
      [partner.id, title, description || "", Number(price || 0)]
    );
    await client.query("COMMIT");
    res.json({ success: true });
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("api create service err", err);
    res.status(500).json({ error: String(err) });
  } finally {
    client.release();
  }
});

export default router;
