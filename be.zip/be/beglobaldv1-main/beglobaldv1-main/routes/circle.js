import { Router } from "express";
import fetch from "node-fetch";
import dotenv from "dotenv";

dotenv.config();

const router = Router();

// List members from Circle (proxy endpoint)
router.get("/api/admin/list-users", async (req, res) => {
  const token = process.env.CIRCLE_API_TOKEN;
  if (!token)
    return res.json({ success: false, error: "CIRCLE_API_TOKEN not set" });

  try {
    const url = "https://api.circle.so/api/v1/members";
    const r = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
    });

    if (!r.ok) {
      const txt = await r.text();
      console.error("circle api error", r.status, txt);
      return res.json({
        success: false,
        error: `Circle API error ${r.status}`,
      });
    }

    const data = await r.json();
    res.json({ success: true, data });
  } catch (err) {
    console.error("circle fetch err", err);
    res.json({ success: false, error: String(err) });
  }
});

// Avatar Proxy for Circle
router.get("/avatar/:memberId", async (req, res) => {
  const memberId = req.params.memberId;
  const token = process.env.CIRCLE_API_TOKEN;

  if (!token) return res.status(400).send("No token");

  try {
    const apiRes = await fetch(
      `https://api.circle.so/api/v1/members/${memberId}`,
      {
        headers: { Authorization: `Bearer ${token}` },
      }
    );

    if (!apiRes.ok)
      return res.status(apiRes.status).send("Failed to fetch avatar");

    const data = await apiRes.json();
    const avatarUrl = data?.avatarUrl;
    if (!avatarUrl) return res.status(404).send("No avatar");

    // fetch actual image
    const imgRes = await fetch(avatarUrl);
    const buffer = await imgRes.arrayBuffer();

    res.setHeader("Content-Type", imgRes.headers.get("content-type"));
    res.send(Buffer.from(buffer));
  } catch (err) {
    console.error(err);
    res.status(500).send("Error fetching avatar");
  }
});

export default router;
