import { Router } from "express";
import pool from "../config/database.js";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const router = Router();

// Helper: Get service with partner info
async function getServiceWithPartner(serviceId) {
  const result = await pool.query(
    `SELECT s.id, s.title, s.description, s.price, s.status,
            u.full_name as partner_name, u.email as partner_email
     FROM service s
     JOIN app_user u ON u.id = s.partner_id
     WHERE s.id = $1 AND s.status = 'ACTIVE'
     LIMIT 1`,
    [serviceId]
  );
  return result.rows[0] || null;
}

// Serve a tiny embed stylesheet
router.get("/embed.css", (req, res) => {
  res.type("text/css");
  res.sendFile(path.join(__dirname, "..", "public", "embed.css"));
});

// Small card fragment (useful for Circle posts: tiny preview HTML)
router.get("/embed/card/:id", async (req, res) => {
  try {
    const service = await getServiceWithPartner(req.params.id);

    if (!service) {
      return res.status(404).render("embed-card", {
        title: "Service Not Found",
        description: "This service is no longer available.",
        price: 0,
        partnerName: "",
        serviceId: req.params.id,
      });
    }

    res.render("embed-card", {
      title: service.title,
      description: service.description || "",
      price: Number(service.price) || 0,
      partnerName: service.partner_name || service.partner_email || "Unknown",
      serviceId: service.id,
    });
  } catch (err) {
    console.error("Embed card error:", err);
    res.status(500).render("embed-card", {
      title: "Error",
      description: "Unable to load service.",
      price: 0,
      partnerName: "",
      serviceId: req.params.id,
    });
  }
});

// Full compact service page for embedding in iframe (includes request form)
router.get("/embed/service/:id", async (req, res) => {
  try {
    const service = await getServiceWithPartner(req.params.id);

    if (!service) {
      return res.status(404).send("Service not found or no longer available.");
    }

    res.render("embed-service", {
      title: service.title,
      description: service.description || "",
      price: Number(service.price) || 0,
      partnerName: service.partner_name || service.partner_email || "Unknown",
      serviceId: service.id,
    });
  } catch (err) {
    console.error("Embed service error:", err);
    res.status(500).send("Unable to load service. Please try again later.");
  }
});

export default router;
