import { Router } from "express";
import pool from "../config/database.js";
import { findUserByEmail, findOrCreateUser } from "../models/user.js";
import { v4 as uuidv4 } from "uuid";

const router = Router();

// -------------------- BUILDER REVIEW SUBMISSION --------------------

// Builder: submit review for a service they've received (DELIVERED status)
router.post("/service/:id/review", async (req, res) => {
  const serviceId = req.params.id;
  const { builder_email, builder_name, rating, comment } = req.body;

  if (!builder_email || !rating) {
    return res.status(400).send("builder_email and rating required");
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    // Find or create builder
    const builder = await findOrCreateUser({
      email: builder_email,
      full_name: builder_name || "",
      role: "BUILDER",
    });

    // Get service details for redirect
    const svcRes = await client.query(
      `select * from service where id = $1 limit 1`,
      [serviceId]
    );
    if (!svcRes.rowCount) {
      await client.query("ROLLBACK");
      return res.status(404).send("Service not found");
    }

    // Check if builder has at least one DELIVERED request for this service
    const hasDeliveredRequest = await client.query(
      `select id from service_request
       where service_id = $1
         and builder_id = $2
         and status = 'DELIVERED'
       limit 1`,
      [serviceId, builder.id]
    );

    if (!hasDeliveredRequest.rowCount) {
      await client.query("ROLLBACK");
      return res.redirect(
        `/service/${serviceId}?builder_email=${encodeURIComponent(
          builder.email
        )}&message=${encodeURIComponent(
          "You can only review services you have received."
        )}`
      );
    }

    const requestId = hasDeliveredRequest.rows[0].id;

    // Check if review already exists for this request
    const existingReview = await client.query(
      `select id from review where request_id = $1 limit 1`,
      [requestId]
    );

    if (existingReview.rowCount) {
      await client.query("ROLLBACK");
      return res.redirect(
        `/service/${serviceId}?builder_email=${encodeURIComponent(
          builder.email
        )}&message=${encodeURIComponent(
          "You have already reviewed this service."
        )}`
      );
    }

    // Get partner_id from request
    const reqData = await client.query(
      `select partner_id from service_request where id = $1`,
      [requestId]
    );
    const partnerId = reqData.rows[0].partner_id;

    // Validate rating (1-5)
    const ratingInt = Math.max(1, Math.min(5, parseInt(rating, 10) || 0));

    // Insert review
    await client.query(
      `insert into review (id, request_id, builder_id, partner_id, rating, comment, visible)
       values ($1, $2, $3, $4, $5, $6, $7)`,
      [
        uuidv4(),
        requestId,
        builder.id,
        partnerId,
        ratingInt,
        comment || "",
        false,
      ]
    );

    // Update request status to REVIEWED
    await client.query(
      `update service_request set status = 'REVIEWED' where id = $1`,
      [requestId]
    );

    await client.query("COMMIT");

    res.redirect(
      `/service/${serviceId}?builder_email=${encodeURIComponent(
        builder.email
      )}&message=${encodeURIComponent("Thank you for your review!")}`
    );
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("review submission error:", err);
    res
      .status(500)
      .send("Server error while posting review: " + String(err.message));
  } finally {
    client.release();
  }
});

// -------------------- ADMIN REVIEW MANAGEMENT --------------------

// Admin: toggle review visibility
router.post("/admin/review/:id/toggle-visibility", async (req, res) => {
  const reviewId = req.params.id;

  try {
    // Toggle the visible field
    await pool.query(`update review set visible = NOT visible where id = $1`, [
      reviewId,
    ]);

    res.redirect("back");
  } catch (err) {
    console.error("toggle review visibility error:", err);
    res.status(500).send("Server error");
  }
});

// Admin: delete review
router.post("/admin/review/:id/delete", async (req, res) => {
  const reviewId = req.params.id;

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    // Get the request_id before deleting
    const reviewData = await client.query(
      `select request_id from review where id = $1`,
      [reviewId]
    );

    if (reviewData.rowCount) {
      const requestId = reviewData.rows[0].request_id;

      // Delete the review
      await client.query(`delete from review where id = $1`, [reviewId]);

      // Optionally: revert request status back to DELIVERED
      await client.query(
        `update service_request set status = 'DELIVERED' where id = $1 and status = 'REVIEWED'`,
        [requestId]
      );
    }

    await client.query("COMMIT");
    res.redirect("back");
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("delete review error:", err);
    res.status(500).send("Server error");
  } finally {
    client.release();
  }
});

export default router;
