import { Router } from "express";
import pool from "../config/database.js";
import { findUserByEmail, findOrCreateUser } from "../models/user.js";
import {
  ensureWallet,
  createLedgerEntry,
  holdFromBuilder,
  transferHoldToPartner,
  releaseHoldToBuilder,
} from "../models/wallet.js";
import { v4 as uuidv4 } from "uuid";

const router = Router();

// BROWSE - catalog servicii
router.get("/browse", async (req, res) => {
  try {
    const servicesRes =
      await pool.query(`select s.*, u.full_name as partner_name, u.email as partner_email
                                          from service s
                                          join app_user u on u.id = s.partner_id
                                          where s.status = 'ACTIVE'
                                          order by s.created_at desc`);
    const services = servicesRes.rows || [];

    // If builder info passed as query, populate currentBuilder
    let currentBuilder = null;
    if (req.query.builder_email) {
      const b = await findUserByEmail(req.query.builder_email);
      if (b) currentBuilder = b;
    }

    res.render("browse", { services, currentBuilder });
  } catch (err) {
    console.error("browse error:", err);
    res.status(500).send("Server error");
  }
});

// SERVICE detail (accepts /service/:id or /service?id=...)
router.get("/service/:id", async (req, res) => {
  const id = req.params.id;
  try {
    const srv = await pool.query(
      `select s.*, u.full_name as partner_name, u.email as partner_email
                                  from service s
                                  join app_user u on u.id = s.partner_id
                                  where s.id = $1 limit 1`,
      [id]
    );
    if (!srv.rowCount) return res.status(404).send("Service not found");
    const service = srv.rows[0];

    let currentBuilder = null;
    if (req.query.builder_email) {
      currentBuilder = await findUserByEmail(req.query.builder_email);
    }

    // optional message param for flash-like responses
    const message = req.query.message || null;

    res.render("service", { service, currentBuilder, message });
  } catch (err) {
    console.error("service error:", err);
    res.status(500).send("Server error");
  }
});

// POST service request (from form on service page)
router.post("/service/:id/request", async (req, res) => {
  const serviceId = req.params.id;
  const { builder_email, builder_name } = req.body;

  if (!builder_email) {
    return res.status(400).send("builder email required");
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    // ensure builder user exists
    const builder = await findOrCreateUser({
      email: builder_email,
      full_name: builder_name || "",
      role: "BUILDER",
    });

    // get service
    const sres = await client.query(
      `select * from service where id = $1 limit 1`,
      [serviceId]
    );
    if (sres.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).send("Service not found");
    }
    const service = sres.rows[0];

    // create request
    const requestId = uuidv4();
    const amount = Number(service.price || 0);

    await client.query(
      `insert into service_request (id, service_id, builder_id, partner_id, amount, circle_thread_id)
       values ($1,$2,$3,$4,$5,$6)`,
      [requestId, service.id, builder.id, service.partner_id, amount, null]
    );

    // ensure wallets
    await ensureWallet(builder.id);
    await ensureWallet(service.partner_id);

    // move funds to hold from builder
    const newWallet = await holdFromBuilder(client, builder.id, amount);

    // ledger entry for HOLD by builder
    await createLedgerEntry(client, {
      request_id: requestId,
      user_id: builder.id,
      type: "HOLD",
      amount,
    });

    await client.query("COMMIT");

    // redirect to builder portal
    const encodedEmail = encodeURIComponent(builder.email);
    const encodedName = encodeURIComponent(builder.full_name || "Builder");
    res.redirect(`/circle/builder?email=${encodedEmail}&name=${encodedName}`);
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("request error:", err);
    res
      .status(500)
      .send("Server error while creating request: " + String(err.message));
  } finally {
    client.release();
  }
});

// POST partner accepts request -> status IN_PROGRESS
router.post("/request/:id/accept", async (req, res) => {
  const id = req.params.id;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const r1 = await client.query(
      `select * from service_request where id=$1 for update`,
      [id]
    );
    if (r1.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).send("Request not found");
    }
    const reqRow = r1.rows[0];
    if (reqRow.status !== "REQUESTED") {
      await client.query("ROLLBACK");
      return res.status(400).send("Can only accept REQUESTED requests");
    }
    await client.query(
      `update service_request set status='IN_PROGRESS' where id=$1`,
      [id]
    );
    await client.query("COMMIT");
    res.redirect("back");
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("accept error:", err);
    res.status(500).send("Server error");
  } finally {
    client.release();
  }
});

// Partner deliver -> transfer funds from builder hold to partner balance
router.post("/request/:id/deliver", async (req, res) => {
  const id = req.params.id;
  const delivery_note = req.body.delivery_note || null;

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const r = await client.query(
      `select * from service_request where id=$1 for update`,
      [id]
    );
    if (r.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).send("Request not found");
    }
    const reqRow = r.rows[0];

    if (reqRow.status === "DELIVERED" || reqRow.status === "REVIEWED") {
      await client.query("ROLLBACK");
      return res.status(400).send("Request already delivered/reviewed");
    }

    // transfer hold -> partner
    const amount = Number(reqRow.amount || 0);
    await transferHoldToPartner(
      client,
      reqRow.builder_id,
      reqRow.partner_id,
      amount,
      id
    );

    // update request
    await client.query(
      `update service_request set status='DELIVERED', delivered_at = now() where id=$1`,
      [id]
    );

    await client.query("COMMIT");

    res.redirect("back");
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("deliver error:", err);
    res.status(500).send("Server error: " + String(err.message));
  } finally {
    client.release();
  }
});

// Partner cancel/reject -> release hold back to builder and mark CANCELLED
router.post("/request/:id/cancel", async (req, res) => {
  const id = req.params.id;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const r = await client.query(
      `select * from service_request where id=$1 for update`,
      [id]
    );
    if (r.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).send("Request not found");
    }
    const reqRow = r.rows[0];

    if (reqRow.status === "CANCELLED" || reqRow.status === "REVIEWED") {
      await client.query("ROLLBACK");
      return res.status(400).send("Request already finalized");
    }

    const amount = Number(reqRow.amount || 0);
    // release hold back to builder
    await releaseHoldToBuilder(client, reqRow.builder_id, amount, id);

    // update request
    await client.query(
      `update service_request set status='CANCELLED' where id=$1`,
      [id]
    );

    await client.query("COMMIT");
    res.redirect("back");
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("cancel error:", err);
    res.status(500).send("Server error");
  } finally {
    client.release();
  }
});

// POST create service (from your post-service form)
router.post("/post-service", async (req, res) => {
  const { title, description, price, email } = req.body;
  console.log("post-service body:", req.body);
  if (!email) return res.status(400).send("Partner email required");

  // Find or create partner
  const partner = await findOrCreateUser({ email, role: "PARTNER" });
  console.log("Service created for partner:", partner);

  if (!title || typeof price === "undefined") {
    return res.status(400).send("Missing title or price");
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    // Create service
    await client.query(
      `insert into service (partner_id, title, description, price, status)
       values ($1,$2,$3,$4,'ACTIVE')`,
      [partner.id, title, description || "", Number(price)]
    );
    await client.query("COMMIT");

    // Redirect using Circle user data from sessionStorage (sent via form)
    const circleEmail = req.body.circle_email;
    const circleName = req.body.circle_name || "Partner";

    if (circleEmail) {
      const redirectUrl =
        "/circle/partner?email=" +
        encodeURIComponent(circleEmail) +
        "&name=" +
        encodeURIComponent(circleName);
      res.redirect(redirectUrl);
    } else {
      // Fallback if no Circle user data
      res.redirect("/browse");
    }
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("post-service error:", err);
    res.status(500).send("Server error");
  } finally {
    client.release();
  }
});

// GET post-service page (optionally prefill partner via query)
router.get("/post-service", async (req, res) => {
  let currentPartner = null;
  if (req.query.email) {
    currentPartner = await findUserByEmail(req.query.email);
  }
  res.render("post-service", { currentPartner, message: null });
});

export default router;
