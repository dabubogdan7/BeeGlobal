import { Router } from "express";

const router = Router();

// Root redirect to browse
router.get("/", (req, res) => res.redirect("/browse"));

// Healthcheck endpoint
router.get("/health", (req, res) => res.send("OK"));

export default router;
