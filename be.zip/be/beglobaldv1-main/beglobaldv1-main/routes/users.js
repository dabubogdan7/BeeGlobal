import { Router } from "express";
import pool from "../config/database.js";
import { findUserByEmail, findOrCreateUser } from "../models/user.js";
import { v4 as uuidv4 } from "uuid";

const router = Router();

// Helper query function
async function q(text, params) {
  const r = await pool.query(text, params);
  return r;
}

// Helper: resolve partner from query
async function resolvePartnerFromQuery(req) {
  const email = req.query.partner_email || req.query.email;
  const name = req.query.partner_name || req.query.name || "Circle Partner";

  if (!email) return null;

  let user = (await q("select * from app_user where email=$1", [email]))
    .rows[0];

  if (!user) {
    user = (
      await q(
        `insert into app_user (id,email,full_name,role)
         values ($1,$2,$3,$4)
         returning *`,
        [uuidv4(), email, name, "PARTNER"]
      )
    ).rows[0];

    await q(
      "insert into wallet (user_id,balance,hold_balance) values ($1,$2,$3)",
      [user.id, 0, 0]
    );
  } else if (!user.full_name && name) {
    await q("update app_user set full_name=$1 where id=$2", [name, user.id]);
    user.full_name = name;
  }

  return {
    id: user.id,
    email: user.email,
    full_name: user.full_name,
  };
}

// Builder: view own requests
router.get("/builder/:email/requests", async (req, res) => {
  const email = req.params.email;
  try {
    const user = await findUserByEmail(email);
    if (!user) return res.status(404).send("Builder not found");

    const reqs = await pool.query(
      `select sr.*, s.title as service_title, p.full_name as partner_name, p.email as partner_email
       from service_request sr
       join service s on s.id = sr.service_id
       join app_user p on p.id = sr.partner_id
       where sr.builder_id = $1
       order by sr.created_at desc`,
      [user.id]
    );

    res.render("builder-portal", { builder: user, requests: reqs.rows || [] });
  } catch (err) {
    console.error("builder requests error:", err);
    res.status(500).send("Server error");
  }
});

// Partner: view portal
router.get("/partner/:email/portal", async (req, res) => {
  const email = req.params.email;
  try {
    const partner = await findUserByEmail(email);
    if (!partner) return res.status(404).send("Partner not found");

    // partner's services
    const services = (
      await pool.query(
        `select * from service where partner_id = $1 order by created_at desc`,
        [partner.id]
      )
    ).rows;

    // partner's received requests
    const requests = (
      await pool.query(
        `select sr.*, s.title as service_title, b.full_name as builder_name, b.email as builder_email
       from service_request sr
       join service s on s.id = sr.service_id
       join app_user b on b.id = sr.builder_id
       where sr.partner_id = $1
       order by sr.created_at desc`,
        [partner.id]
      )
    ).rows;

    res.render("partner-portal", { partner, services, requests });
  } catch (err) {
    console.error("partner portal err:", err);
    res.status(500).send("Server error");
  }
});

// Partner: view partner requests (alias)
router.get("/partner/:email/requests", async (req, res) => {
  const email = req.params.email;
  try {
    const partner = await findUserByEmail(email);
    if (!partner) return res.status(404).send("Partner not found");

    const requests = (
      await pool.query(
        `select sr.*, s.title as service_title, b.full_name as builder_name, b.email as builder_email
       from service_request sr
       join service s on s.id = sr.service_id
       join app_user b on b.id = sr.builder_id
       where sr.partner_id = $1
       order by sr.created_at desc`,
        [partner.id]
      )
    ).rows;

    res.render("partner-requests", { partner, requests });
  } catch (err) {
    console.error("partner requests err:", err);
    res.status(500).send("Server error");
  }
});

// Circle Builder Portal (query params)
router.get("/circle/builder", async (req, res) => {
  const email = req.query.email;
  const name = req.query.name;

  if (!email) return res.status(400).send("Email required");

  try {
    const user = await findOrCreateUser({
      email,
      full_name: name || "",
      role: "BUILDER",
    });

    const reqs = await pool.query(
      `select sr.*, s.title as service_title, p.full_name as partner_name, p.email as partner_email
       from service_request sr
       join service s on s.id = sr.service_id
       join app_user p on p.id = sr.partner_id
       where sr.builder_id = $1
       order by sr.created_at desc`,
      [user.id]
    );

    res.render("builder-portal", { builder: user, requests: reqs.rows || [] });
  } catch (err) {
    console.error("circle builder portal error:", err);
    res.status(500).send("Server error");
  }
});

// Circle Partner Portal
router.get("/circle/partner", async (req, res) => {
  const currentPartner = await resolvePartnerFromQuery(req);
  if (!currentPartner) {
    return res.status(400).send("Lipsește email-ul (?email=...)");
  }

  // Serviciile lui
  const services = (
    await q(
      "select * from service where partner_id=$1 order by created_at desc",
      [currentPartner.id]
    )
  ).rows;

  // Cererile primite pe serviciile lui
  const requests = (
    await q(
      `select r.*,
              s.title as service_title,
              b.full_name as builder_name,
              b.email     as builder_email
       from service_request r
       join service   s on s.id = r.service_id
       join app_user  b on b.id = r.builder_id
       where r.partner_id=$1
       order by r.created_at desc`,
      [currentPartner.id]
    )
  ).rows;

  res.render("partner-portal", {
    partner: currentPartner,
    services,
    requests,
  });
});

export default router;
