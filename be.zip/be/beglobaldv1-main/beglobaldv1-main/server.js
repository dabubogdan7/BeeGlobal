import express from "express";
import bodyParser from "body-parser";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import pool from "./config/database.js";
import { corsMiddleware, cspMiddleware } from "./middleware/cors.js";
import { userInjectionMiddleware } from "./middleware/auth.js";
import servicesRoutes from "./routes/services.js";
import usersRoutes from "./routes/users.js";
import adminRoutes from "./routes/admin.js";
import apiRoutes from "./routes/api.js";
import embedRoutes from "./routes/embed.js";
import circleRoutes from "./routes/circle.js";
import systemRoutes from "./routes/system.js";
import reviewsRoutes from "./routes/reviews.js";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();

// -------------------- Middleware --------------------
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(corsMiddleware);
app.use(cspMiddleware);
app.use(userInjectionMiddleware);

// Static files
app.use(express.static(path.join(__dirname, "public")));

// EJS templating
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// -------------------- Routes --------------------
app.use(systemRoutes);
app.use(servicesRoutes);
app.use(usersRoutes);
app.use(adminRoutes);
app.use(apiRoutes);
app.use(embedRoutes);
app.use(circleRoutes);
app.use(reviewsRoutes);

// 404 handler (must be last)
app.use((req, res) => {
  res.status(404).send("Not found");
});

// -------------------- Start Server --------------------
const PORT = Number(process.env.PORT) || 3001;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
