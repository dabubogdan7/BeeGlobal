-- SQL init for Circle Marketplace Demo (database: bank_italia)
create extension if not exists "uuid-ossp";

create type service_status as enum ('DRAFT','PENDING_REVIEW','ACTIVE','REJECTED');
create type request_status as enum ('REQUESTED','IN_PROGRESS','DELIVERED','REVIEWED','CANCELLED');
create type entry_type as enum ('CREDIT','DEBIT','HOLD','RELEASE','DEDUCT');

create table if not exists app_user (
  id uuid primary key default uuid_generate_v4(),
  email text unique not null,
  full_name text not null,
  role text check (role in ('BUILDER','PARTNER','ADMIN')) not null,
  created_at timestamptz default now()
);

create table if not exists wallet (
  user_id uuid primary key references app_user(id) on delete cascade,
  balance bigint not null default 0,
  hold_balance bigint not null default 0
);

create table if not exists partner_profile (
  user_id uuid primary key references app_user(id) on delete cascade,
  company_name text,
  bio text
);

create table if not exists service (
  id uuid primary key default uuid_generate_v4(),
  partner_id uuid not null references app_user(id),
  title text not null,
  description text,
  price bigint not null check (price>=0),
  status service_status not null default 'DRAFT',
  created_at timestamptz default now()
);

create table if not exists service_request (
  id uuid primary key default uuid_generate_v4(),
  service_id uuid not null references service(id),
  builder_id uuid not null references app_user(id),
  partner_id uuid not null references app_user(id),
  status request_status not null default 'REQUESTED',
  amount bigint not null,
  circle_thread_id text,
  created_at timestamptz default now(),
  delivered_at timestamptz
);

create table if not exists ledger_entry (
  id uuid primary key default uuid_generate_v4(),
  request_id uuid references service_request(id),
  user_id uuid not null references app_user(id),
  type entry_type not null,
  amount bigint not null check (amount>0),
  created_at timestamptz default now()
);

create table if not exists review (
  id uuid primary key default uuid_generate_v4(),
  request_id uuid unique references service_request(id),
  builder_id uuid not null references app_user(id),
  partner_id uuid not null references app_user(id),
  rating int check (rating between 1 and 5),
  comment text,
  visible boolean default false,
  created_at timestamptz default now()
);

-- sample data
insert into app_user (email, full_name, role) values
('partner@demo.local','Demo Partner','PARTNER'),
('builder@demo.local','Demo Builder','BUILDER'),
('admin@demo.local','Admin','ADMIN')
on conflict (email) do nothing;

-- wallets
insert into wallet (user_id, balance, hold_balance)
select id, case when role='BUILDER' then 1000 else 0 end, 0
from app_user
on conflict (user_id) do nothing;

-- sample service
insert into service (partner_id, title, description, price, status)
select id, 'Design landing page', 'Design a clean responsive landing page', 200, 'ACTIVE'
from app_user where email='partner@demo.local'
on conflict do nothing;

create index if not exists idx_service_status on service(status);
create index if not exists idx_request_status on service_request(status);
