// models/wallet.js
import pool from "../config/database.js";

/**
 * ensureWallet(userId)
 * - se asigură că există un wallet pentru user_id
 */
export async function ensureWallet(userId) {
  if (!userId) throw new Error("ensureWallet: userId required");

  // nu mai folosim coloana "id", folosim user_id ca PK
  const existing = await pool.query(
    `select user_id
       from wallet
       where user_id = $1
       limit 1`,
    [userId]
  );

  if (!existing.rowCount) {
    await pool.query(
      `insert into wallet (user_id, balance, hold)
       values ($1, 0, 0)`,
      [userId]
    );
  }
}

/**
 * createLedgerEntry – log de tranzacție
 */
export async function createLedgerEntry(clientOrNull, {
  request_id,
  user_id,
  type,
  amount,
}) {
  const client = clientOrNull || pool;

  await client.query(
    `insert into wallet_ledger (request_id, user_id, type, amount)
     values ($1, $2, $3, $4)`,
    [request_id, user_id, type, amount]
  );
}

/**
 * holdFromBuilder – mută din balance în hold pentru builder
 */
export async function holdFromBuilder(client, builderId, amount) {
  if (!client) throw new Error("holdFromBuilder: client required");
  if (!builderId) throw new Error("holdFromBuilder: builderId required");

  const { rows, rowCount } = await client.query(
    `select *
       from wallet
       where user_id = $1
       for update`,
    [builderId]
  );

  if (!rowCount) {
    throw new Error("Wallet not found for builder");
  }

  const w = rows[0];
  const balance = Number(w.balance || 0);
  const hold = Number(w.hold || 0);
  const amt = Number(amount || 0);

  if (balance < amt) {
    throw new Error("Insufficient credits in builder wallet");
  }

  await client.query(
    `update wallet
       set balance = $2,
           hold    = $3
     where user_id = $1`,
    [builderId, balance - amt, hold + amt]
  );
}

/**
 * transferHoldToPartner – la livrare:
 * - scade din hold-ul builderului
 * - crește balance-ul partenerului
 */
export async function transferHoldToPartner(
  client,
  builderId,
  partnerId,
  amount,
  requestId
) {
  if (!client) throw new Error("transferHoldToPartner: client required");

  const amt = Number(amount || 0);

  // wallet builder – lock
  const bwRes = await client.query(
    `select *
       from wallet
       where user_id = $1
       for update`,
    [builderId]
  );
  if (!bwRes.rowCount) throw new Error("Builder wallet not found");
  const bw = bwRes.rows[0];

  // wallet partner – lock
  const pwRes = await client.query(
    `select *
       from wallet
       where user_id = $1
       for update`,
    [partnerId]
  );
  if (!pwRes.rowCount) throw new Error("Partner wallet not found");
  const pw = pwRes.rows[0];

  const builderHold = Number(bw.hold || 0);
  if (builderHold < amt) {
    throw new Error("Builder HOLD balance is lower than amount");
  }

  // scădem din hold-ul builderului
  await client.query(
    `update wallet
       set hold = $2
     where user_id = $1`,
    [builderId, builderHold - amt]
  );

  // adăugăm la balance partenerului
  const partnerBalance = Number(pw.balance || 0);
  await client.query(
    `update wallet
       set balance = $2
     where user_id = $1`,
    [partnerId, partnerBalance + amt]
  );

  await createLedgerEntry(client, {
    request_id: requestId,
    user_id: partnerId,
    type: "RECEIVE",
    amount: amt,
  });
}

/**
 * releaseHoldToBuilder – la cancel:
 * - mută din hold înapoi în balance
 */
export async function releaseHoldToBuilder(
  client,
  builderId,
  amount,
  requestId
) {
  if (!client) throw new Error("releaseHoldToBuilder: client required");

  const { rows, rowCount } = await client.query(
    `select *
       from wallet
       where user_id = $1
       for update`,
    [builderId]
  );
  if (!rowCount) throw new Error("Builder wallet not found");

  const w = rows[0];
  const hold = Number(w.hold || 0);
  const balance = Number(w.balance || 0);
  const amt = Number(amount || 0);

  if (hold < amt) {
    throw new Error("Builder HOLD balance is lower than amount to release");
  }

  await client.query(
    `update wallet
       set hold    = $2,
           balance = $3
     where user_id = $1`,
    [builderId, hold - amt, balance + amt]
  );

  await createLedgerEntry(client, {
    request_id: requestId,
    user_id: builderId,
    type: "RELEASE",
    amount: amt,
  });
}
