import { Router } from "express";
import pool from "../config/database.js";
import { findUserByEmail, findOrCreateUser } from "../models/user.js";
import {
  ensureWallet,
  createLedgerEntry,
  holdFromBuilder,
  transferHoldToPartner,
  releaseHoldToBuilder,
} from "../models/wallet.js";
import { v4 as uuidv4 } from "uuid";

const router = Router();

/**
 * CATALOG – BROWSE
 * GET /browse
 */
router.get("/browse", async (req, res) => {
  try {
    const servicesRes = await pool.query(
      `select s.*,
              u.full_name as partner_name,
              u.email     as partner_email
       from service s
       join app_user u on u.id = s.partner_id
       where s.status = 'ACTIVE'
       order by s.created_at desc`
    );
    const services = servicesRes.rows || [];

    let currentBuilder = null;
    if (req.query.builder_email) {
      const b = await findUserByEmail(req.query.builder_email);
      if (b) currentBuilder = b;
    }

    res.render("browse", { services, currentBuilder });
  } catch (err) {
    console.error("browse error:", err);
    res.status(500).send("Server error");
  }
});

/**
 * SERVICE DETAIL
 * GET /service/:id
 */
router.get("/service/:id", async (req, res) => {
  const id = req.params.id;
  try {
    const srv = await pool.query(
      `select s.*,
              u.full_name as partner_name,
              u.email     as partner_email
       from service s
       join app_user u on u.id = s.partner_id
       where s.id = $1
       limit 1`,
      [id]
    );
    if (!srv.rowCount) return res.status(404).send("Service not found");

    const service = srv.rows[0];

    let currentBuilder = null;
    if (req.query.builder_email) {
      currentBuilder = await findUserByEmail(req.query.builder_email);
    }

    const message = req.query.message || null;
    const error = req.query.error || null;

    // poate lăsa review doar dacă are cel puțin un request DELIVERED/REVIEWED
    let canReview = false;
    if (currentBuilder) {
      const canReviewRes = await pool.query(
        `
        select 1
        from service_request
        where service_id = $1
          and builder_id = $2
          and status in ('DELIVERED','REVIEWED')
        limit 1
        `,
        [service.id, currentBuilder.id]
      );
      canReview = !!canReviewRes.rowCount;
    }

    res.render("service", { service, currentBuilder, message, error, canReview });
  } catch (err) {
    console.error("service error:", err);
    res.status(500).send("Server error");
  }
});

/**
 * BUILDER -> REQUEST SERVICE
 * POST /service/:id/request
 */
router.post("/service/:id/request", async (req, res) => {
  const serviceId = req.params.id;
  const { builder_email, builder_name } = req.body;

  if (!builder_email) {
    return res.status(400).send("builder email required");
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    // asigurăm builder-ul
    const builder = await findOrCreateUser({
      email: builder_email,
      full_name: builder_name || "",
      role: "BUILDER",
    });

    // luăm serviciul
    const sres = await client.query(
      `select * from service where id = $1 limit 1`,
      [serviceId]
    );
    if (sres.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).send("Service not found");
    }
    const service = sres.rows[0];

    const requestId = uuidv4();
    const amount = Number(service.price || 0);

    // asigurăm wallet-urile înainte de verificare
    await ensureWallet(builder.id);
    await ensureWallet(service.partner_id);

    // verificăm creditele disponibile în wallet-ul builder-ului
    const balRes = await client.query(
      `
      select w.balance
      from wallet w
      join team t on t.id = w.team_id
      join app_user b on b.id = t.primary_builder_id
      where b.id = $1
      limit 1
      `,
      [builder.id]
    );
    const balance = balRes.rowCount ? Number(balRes.rows[0].balance || 0) : 0;

    if (balance < amount) {
      await client.query("ROLLBACK");
      const encodedEmail = encodeURIComponent(builder.email);
      const encodedName = encodeURIComponent(builder.full_name || "Builder");
      const errorMsg = encodeURIComponent(
        `Insufficient credits. You need ${amount} credits but have only ${balance}.`
      );
      return res.redirect(
        `/service/${service.id}?builder_email=${encodedEmail}&builder_name=${encodedName}&error=${errorMsg}`
      );
    }

    // creăm cererea
    await client.query(
      `insert into service_request
         (id, service_id, builder_id, partner_id, amount, circle_thread_id)
       values ($1,$2,$3,$4,$5,$6)`,
      [requestId, service.id, builder.id, service.partner_id, amount, null]
    );

    // mutăm fondurile în HOLD din wallet-ul builder-ului
    await holdFromBuilder(client, builder.id, amount);

    // ledger entry pentru HOLD
    await createLedgerEntry(client, {
      request_id: requestId,
      user_id: builder.id,
      type: "HOLD",
      amount,
    });

    await client.query("COMMIT");

    const encodedEmail = encodeURIComponent(builder.email);
    const encodedName = encodeURIComponent(builder.full_name || "Builder");
    res.redirect(`/circle/builder?email=${encodedEmail}&name=${encodedName}`);
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("request error:", err);
    res
      .status(500)
      .send("Server error while creating request: " + String(err.message));
  } finally {
    client.release();
  }
});

/**
 * PARTNER ACCEPT REQUEST
 * POST /request/:id/accept
 */
router.post("/request/:id/accept", async (req, res) => {
  const id = req.params.id;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const r1 = await client.query(
      `select * from service_request where id=$1 for update`,
      [id]
    );
    if (r1.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).send("Request not found");
    }
    const reqRow = r1.rows[0];

    if (reqRow.status !== "REQUESTED") {
      await client.query("ROLLBACK");
      return res.status(400).send("Can only accept REQUESTED requests");
    }

    await client.query(
      `update service_request
         set status='IN_PROGRESS'
       where id=$1`,
      [id]
    );

    await client.query("COMMIT");
    res.redirect("back");
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("accept error:", err);
    res.status(500).send("Server error");
  } finally {
    client.release();
  }
});

/**
 * PARTNER DELIVER -> transfer HOLD -> partner balance
 * POST /request/:id/deliver
 */
router.post("/request/:id/deliver", async (req, res) => {
  const id = req.params.id;
  const delivery_note = req.body.delivery_note || null; // momentan doar îl acceptăm

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const r = await client.query(
      `select * from service_request where id=$1 for update`,
      [id]
    );
    if (r.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).send("Request not found");
    }
    const reqRow = r.rows[0];

    if (reqRow.status === "DELIVERED" || reqRow.status === "REVIEWED") {
      await client.query("ROLLBACK");
      return res.status(400).send("Request already delivered/reviewed");
    }

    const amount = Number(reqRow.amount || 0);

    await transferHoldToPartner(
      client,
      reqRow.builder_id,
      reqRow.partner_id,
      amount,
      id
    );

    await client.query(
      `update service_request
         set status='DELIVERED',
             delivered_at = now()
       where id=$1`,
      [id]
    );

    await client.query("COMMIT");
    res.redirect("back");
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("deliver error:", err);
    res.status(500).send("Server error: " + String(err.message));
  } finally {
    client.release();
  }
});

/**
 * PARTNER CANCEL / REJECT -> release HOLD back to builder
 * POST /request/:id/cancel
 */
router.post("/request/:id/cancel", async (req, res) => {
  const id = req.params.id;
  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    const r = await client.query(
      `select * from service_request where id=$1 for update`,
      [id]
    );
    if (r.rowCount === 0) {
      await client.query("ROLLBACK");
      return res.status(404).send("Request not found");
    }
    const reqRow = r.rows[0];

    if (reqRow.status === "CANCELLED" || reqRow.status === "REVIEWED") {
      await client.query("ROLLBACK");
      return res.status(400).send("Request already finalized");
    }

    const amount = Number(reqRow.amount || 0);

    await releaseHoldToBuilder(client, reqRow.builder_id, amount, id);

    await client.query(
      `update service_request
         set status='CANCELLED'
       where id=$1`,
      [id]
    );

    await client.query("COMMIT");
    res.redirect("back");
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("cancel error:", err);
    res.status(500).send("Server error");
  } finally {
    client.release();
  }
});

/**
 * PARTNER PORTAL – MY SERVICES + SUMMARY REQUESTS
 * GET /partner/:email
 */
router.get("/partner/:email", async (req, res) => {
  const email = req.params.email;

  try {
    const partnerRes = await pool.query(
      `select * from app_user
       where email = $1 and role = 'PARTNER'
       limit 1`,
      [email]
    );

    if (!partnerRes.rowCount) {
      return res.status(404).send("Partner not found");
    }

    const partner = partnerRes.rows[0];

    // servicii ale partenerului
    const servicesRes = await pool.query(
      `select *
       from service
       where partner_id = $1
       order by created_at desc`,
      [partner.id]
    );
    const services = servicesRes.rows || [];

    // request-uri primite
    const requestsRes = await pool.query(
      `select sr.*,
              s.title        as service_title,
              bu.full_name   as builder_name,
              bu.email       as builder_email
       from service_request sr
       join service s   on s.id = sr.service_id
       join app_user bu on bu.id = sr.builder_id
       where sr.partner_id = $1
       order by sr.created_at desc`,
      [partner.id]
    );
    const requests = requestsRes.rows || [];

    res.render("partner-portal", { partner, services, requests });
  } catch (err) {
    console.error("partner portal error:", err);
    res.status(500).send("Server error");
  }
});

/**
 * PARTNER REQUESTS – VIEW ONLY
 * GET /partner/:email/requests
 */
router.get("/partner/:email/requests", async (req, res) => {
  const email = req.params.email;

  try {
    const partnerRes = await pool.query(
      `select * from app_user
       where email = $1 and role = 'PARTNER'
       limit 1`,
      [email]
    );

    if (!partnerRes.rowCount) {
      return res.status(404).send("Partner not found");
    }

    const partner = partnerRes.rows[0];

    const requestsRes = await pool.query(
      `select sr.*,
              s.title        as service_title,
              bu.full_name   as builder_name,
              bu.email       as builder_email
       from service_request sr
       join service s   on s.id = sr.service_id
       join app_user bu on bu.id = sr.builder_id
       where sr.partner_id = $1
       order by sr.created_at desc`,
      [partner.id]
    );
    const requests = requestsRes.rows || [];

    res.render("partner-requests", { partner, requests });
  } catch (err) {
    console.error("partner requests error:", err);
    res.status(500).send("Server error");
  }
});

/**
 * CREATE SERVICE – FORM PAGE
 * GET /post-service
 */
router.get("/post-service", async (req, res) => {
  let currentPartner = null;

  if (req.query.email) {
    currentPartner = await findUserByEmail(req.query.email);
  }

  const message = req.query.message || null;

  res.render("post-service", {
    currentPartner,
    message,
    error: null,
    form: null,
  });
});

/**
 * CREATE SERVICE – HANDLE SUBMIT
 * POST /post-service
 * - price 1–10 credits
 */
router.post("/post-service", async (req, res) => {
  const { title, description, price, email, circle_email, circle_name } =
    req.body;

  console.log("post-service body:", req.body);

  const numericPrice = Number(price);

  // validare preț 1–10 credite
  if (!Number.isInteger(numericPrice) || numericPrice < 1 || numericPrice > 10) {
    let currentPartner = null;
    const partnerEmailForLookup = email || circle_email;

    if (partnerEmailForLookup) {
      currentPartner = await findUserByEmail(partnerEmailForLookup);
    }

    return res.status(400).render("post-service", {
      currentPartner,
      message: null,
      error: "Price must be between 1 and 10 credits.",
      form: { title, description, price },
    });
  }

  const partnerEmail = email || circle_email;
  if (!partnerEmail) {
    return res.status(400).render("post-service", {
      currentPartner: null,
      message: null,
      error: "Partner email required.",
      form: { title, description, price },
    });
  }

  // facem / găsim partnerul
  const partner = await findOrCreateUser({
    email: partnerEmail,
    role: "PARTNER",
    full_name: circle_name || null,
  });

  if (!title) {
    return res.status(400).render("post-service", {
      currentPartner: partner,
      message: null,
      error: "Missing title.",
      form: { title, description, price },
    });
  }

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    await client.query(
      `insert into service (partner_id, title, description, price, status)
       values ($1,$2,$3,$4,'ACTIVE')`,
      [partner.id, title, description || "", numericPrice]
    );

    await client.query("COMMIT");

    // dacă vine din Circle, îl trimitem înapoi în portalul Circle
    if (circle_email) {
      const redirectUrl =
        "/circle/partner?email=" +
        encodeURIComponent(circle_email) +
        "&name=" +
        encodeURIComponent(circle_name || partner.full_name || "Partner");
      return res.redirect(redirectUrl);
    }

    // altfel, portalul nostru de partner
    return res.redirect(
      "/partner/" + encodeURIComponent(partner.email || partnerEmail)
    );
  } catch (err) {
    await client.query("ROLLBACK");
    console.error("post-service error:", err);
    return res.status(500).render("post-service", {
      currentPartner: partner,
      message: null,
      error: "Server error while creating service.",
      form: { title, description, price },
    });
  } finally {
    client.release();
  }
});

/**
 * EDIT SERVICE – FORM
 * GET /service/:id/edit
 */
router.get("/service/:id/edit", async (req, res) => {
  const { id } = req.params;

  try {
    const serviceRes = await pool.query(
      `select s.*,
              u.full_name as partner_name,
              u.email     as partner_email
       from service s
       join app_user u on u.id = s.partner_id
       where s.id = $1`,
      [id]
    );

    if (!serviceRes.rowCount) {
      return res.status(404).send("Service not found");
    }

    const service = serviceRes.rows[0];

    return res.render("edit-service", {
      service,
      error: null,
      message: null,
    });
  } catch (err) {
    console.error("GET /service/:id/edit error", err);
    return res.status(500).send("Internal error");
  }
});

/**
 * EDIT SERVICE – HANDLE SUBMIT
 * POST /service/:id/edit
 * - price 1–10 credits
 */
router.post("/service/:id/edit", async (req, res) => {
  const { id } = req.params;
  const { title, description, price } = req.body;

  const numericPrice = Number(price);

  // validare preț
  if (!Number.isInteger(numericPrice) || numericPrice < 1 || numericPrice > 10) {
    try {
      const serviceRes = await pool.query(
        `select s.*,
                u.full_name as partner_name,
                u.email     as partner_email
         from service s
         join app_user u on u.id = s.partner_id
         where s.id = $1`,
        [id]
      );

      if (!serviceRes.rowCount) {
        return res.status(404).send("Service not found");
      }

      const serviceBase = serviceRes.rows[0];

      return res.status(400).render("edit-service", {
        service: {
          ...serviceBase,
          title,
          description,
          price: isNaN(numericPrice) ? serviceBase.price : numericPrice,
        },
        error: "Price must be between 1 and 10 credits.",
        message: null,
      });
    } catch (err) {
      console.error("POST /service/:id/edit validation error", err);
      return res.status(500).send("Internal error");
    }
  }

  try {
    await pool.query(
      `update service
         set title       = $2,
             description = $3,
             price       = $4
       where id = $1`,
      [id, title, description, numericPrice]
    );

    const serviceRes = await pool.query(
      `select s.*,
              u.full_name as partner_name,
              u.email     as partner_email
       from service s
       join app_user u on u.id = s.partner_id
       where s.id = $1`,
      [id]
    );

    if (!serviceRes.rowCount) {
      return res.status(404).send("Service not found");
    }

    const service = serviceRes.rows[0];

    return res.render("edit-service", {
      service,
      error: null,
      message: "Service updated successfully.",
    });
  } catch (err) {
    console.error("POST /service/:id/edit error", err);
    return res.status(500).send("Internal error");
  }
});

/**
 * DELETE SERVICE
 * POST /service/:id/delete
 */
router.post("/service/:id/delete", async (req, res) => {
  const { id } = req.params;
  const email = req.query.email; // vine din partner-portal.ejs

  try {
    await pool.query(`delete from service where id = $1`, [id]);

    if (email) {
      return res.redirect("/partner/" + encodeURIComponent(email));
    }

    const referer = req.get("referer") || "/browse";
    return res.redirect(referer);
  } catch (err) {
    console.error("POST /service/:id/delete error", err);
    return res.status(500).send("Internal error");
  }
});

/**
 * API – Wallet balance pentru builder
 * GET /api/wallet-balance?email=...
 */
router.get("/api/wallet-balance", async (req, res) => {
  const email = req.query.email;
  if (!email) {
    return res.status(400).json({ error: "Email required" });
  }

  try {
    const r = await pool.query(
      `
      select w.balance
      from wallet w
      join team t on t.id = w.team_id
      join app_user b on b.id = t.primary_builder_id
      where b.email = $1
      limit 1
      `,
      [email]
    );

    if (!r.rowCount) {
      // dacă nu are wallet încă -> 0
      return res.json({ credits: 0 });
    }

    const balance = Number(r.rows[0].balance || 0);
    return res.json({ credits: balance });
  } catch (err) {
    console.error("wallet-balance error:", err);
    return res.status(500).json({ error: "Server error" });
  }
});

/**
 * API – poate lăsa review pentru un serviciu?
 * GET /api/can-review?email=&service_id=
 */
router.get("/api/can-review", async (req, res) => {
  const { email, service_id } = req.query;

  if (!email || !service_id) {
    return res.status(400).json({ error: "email and service_id required" });
  }

  try {
    const userRes = await pool.query(
      `select id from app_user where email = $1 limit 1`,
      [email]
    );
    if (!userRes.rowCount) {
      return res.json({ canReview: false });
    }
    const builderId = userRes.rows[0].id;

    const r = await pool.query(
      `
      select 1
      from service_request
      where service_id = $1
        and builder_id = $2
        and status in ('DELIVERED', 'REVIEWED')
      limit 1
      `,
      [service_id, builderId]
    );

    return res.json({ canReview: r.rowCount > 0 });
  } catch (err) {
    console.error("can-review error:", err);
    return res.status(500).json({ error: "Server error" });
  }
});

// exemplu (admin.js sau server.js)
router.get("/admin", async (req, res) => {
  const walletsRes = await pool.query(`
    select w.*, t.name as team_name, t.id as team_id,
           b.full_name as primary_builder_name,
           b.email as primary_builder_email
    from wallet w
    join team t on t.id = w.team_id
    left join app_user b on b.id = t.primary_builder_id
    order by t.name asc
  `);

  const usersRes = await pool.query(`
    select id, full_name, email, role, created_at
    from app_user
    order by created_at desc
  `);

  const servicesRes = await pool.query(`
    select s.*,
           u.full_name as partner_name,
           u.email as partner_email
    from service s
    join app_user u on u.id = s.partner_id
    order by s.created_at desc
  `);

  res.render("admin", {
    wallets: walletsRes.rows,
    users: usersRes.rows,
    services: servicesRes.rows,
  });
});

export default router;
