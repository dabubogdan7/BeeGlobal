import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import bodyParser from 'body-parser';
import { Pool } from 'pg';
import { v4 as uuidv4 } from 'uuid';

dotenv.config();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3001;

// ===== Views & middlewares =====
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// ===== DB pool =====
const pool = new Pool({
  connectionString:
    process.env.DATABASE_URL ||
    'postgres://postgres:admin@localhost:5432/skillbrain',
});

// Asigurăm search_path pe fiecare conexiune din pool
pool.on('connect', (client) => {
  client.query(`set search_path to beeglobal, public`);
});

// helper query
async function q(text, params) {
  const r = await pool.query(text, params);
  return r;
}

const FRONTEND_URL = process.env.FRONTEND_URL || ''; // ex: https://frontend.tau

// ===== Notificări helper =====
async function notify(userId, type, title, message, url = null) {
  await q(
    `insert into notification (id,user_id,type,title,message,url)
     values ($1,$2,$3,$4,$5,$6)`,
    [uuidv4(), userId, type, title, message, url]
  );
}

/* ------------------------------------------------------------------
   BOOTSTRAP: creează schema minimă + date demo dacă lipsesc tabelele
-------------------------------------------------------------------*/
async function ensureDb() {
  // 0) Schema + search_path
  await q(`create schema if not exists beeglobal`);
  await q(`set search_path to beeglobal, public`);

  // 1) Tabele de bază
  await q(`
    create table if not exists app_user (
      id uuid primary key,
      email text unique not null,
      full_name text not null,
      role text not null check (role in ('BUILDER','PARTNER','ADMIN')),
      created_at timestamptz default now()
    );
  `);

  await q(`
    create table if not exists builder_member (
      id uuid primary key,
      primary_user_id uuid not null references app_user(id) on delete cascade,
      member_user_id uuid not null references app_user(id) on delete cascade,
      created_at timestamptz default now()
    );
  `);

  await q(`
    create table if not exists wallet (
      user_id uuid primary key references app_user(id) on delete cascade,
      balance bigint not null default 0,
      hold_balance bigint not null default 0
    );
  `);

  await q(`
    create table if not exists service (
      id uuid primary key,
      partner_id uuid not null references app_user(id),
      title text not null,
      description text,
      price bigint not null check (price >= 0),
      status text not null check (status in ('DRAFT','PENDING_REVIEW','ACTIVE','REJECTED')) default 'DRAFT',
      created_at timestamptz default now()
    );
  `);

  await q(`
    create table if not exists service_request (
      id uuid primary key,
      service_id uuid not null references service(id),
      builder_id uuid not null references app_user(id),
      partner_id uuid not null references app_user(id),
      status text not null check (status in ('REQUESTED','IN_PROGRESS','DELIVERED','REVIEWED','CANCELLED')) default 'REQUESTED',
      amount bigint not null,
      circle_thread_id text,
      circle_thread_url text,
      delivery_note text,
      created_at timestamptz default now(),
      delivered_at timestamptz
    );
  `);

  await q(`
    create table if not exists ledger_entry (
      id uuid primary key,
      request_id uuid references service_request(id),
      user_id uuid not null references app_user(id),
      type text not null check (type in ('CREDIT','DEBIT','HOLD','RELEASE','DEDUCT')),
      amount bigint not null check (amount > 0),
      created_at timestamptz default now()
    );
  `);

  await q(`
    create table if not exists review (
      id uuid primary key,
      request_id uuid unique references service_request(id),
      builder_id uuid not null references app_user(id),
      partner_id uuid not null references app_user(id),
      rating int check (rating between 1 and 5),
      comment text,
      visible boolean default false,
      created_at timestamptz default now()
    );
  `);

  await q(`
    create table if not exists notification (
      id uuid primary key,
      user_id uuid not null references app_user(id) on delete cascade,
      type text not null,
      title text not null,
      message text not null,
      url text,
      read_at timestamptz,
      created_at timestamptz default now()
    );
  `);
  await q(`create index if not exists idx_notification_user on notification(user_id)`);

  // 2) Seed simplu
  const { rows } = await q(`select count(*)::int as c from app_user`);
  if (rows[0].c === 0) {
    const partnerId = uuidv4();
    const builderId = uuidv4();
    const adminId = uuidv4();

    await q(
      `insert into app_user(id,email,full_name,role) values
      ($1,'partner@demo.local','Demo Partner','PARTNER'),
      ($2,'builder@demo.local','Demo Builder','BUILDER'),
      ($3,'admin@demo.local','Admin','ADMIN')`,
      [partnerId, builderId, adminId]
    );

    await q(
      `insert into wallet(user_id,balance,hold_balance) values
      ($1,0,0),($2,1000,0),($3,0,0)`,
      [partnerId, builderId, adminId]
    );

    const serviceId = uuidv4();
    await q(
      `insert into service(id,partner_id,title,description,price,status)
       values ($1,$2,'Design landing page',
       'Design a clean responsive landing page',200,'ACTIVE')`,
      [serviceId, partnerId]
    );
  }
}

// rulează bootstrap la pornire
ensureDb().catch((e) => {
  console.error('DB bootstrap failed:', e);
  process.exit(1);
});

/* ------------------------------------------------------------------
   Helper: rezolvă builder din query (Circle SSO-like)
-------------------------------------------------------------------*/
// Helper general pentru user venit din Circle (?email=&name=)
async function resolveUserFromCircleQuery(req, expectedRole = 'BUILDER') {
  const email = req.query.email;
  const name  = req.query.name || 'Circle Member';

  if (!email) return null;

  let user = (await q('select * from app_user where email=$1', [email])).rows[0];

  if (!user) {
    // dacă nu există, îl creăm cu rolul așteptat (BUILDER de obicei)
    user = (
      await q(
        `insert into app_user (id,email,full_name,role)
         values ($1,$2,$3,$4)
         returning *`,
        [uuidv4(), email, name, expectedRole]
      )
    ).rows[0];

    // wallet default – builder primește 1000 credite demo, partener 0
    await q(
      'insert into wallet (user_id,balance,hold_balance) values ($1,$2,$3)',
      [user.id, expectedRole === 'BUILDER' ? 1000 : 0, 0]
    );
  } else {
    // dacă există dar n-are nume și vine din Circle, îl completăm
    if (!user.full_name && name) {
      await q('update app_user set full_name=$1 where id=$2', [name, user.id]);
      user.full_name = name;
    }
  }

  return user;
}

/* ------------------------------------------------------------------
   Helper: rezolvă PARTNER din query (Circle SSO-like)
   Acceptă ?partner_email=...&partner_name=...
   sau simplu ?email=...&name=...
-------------------------------------------------------------------*/
/* ------------------------------------------------------------------
   Helper: rezolvă PARTENER din query (Circle SSO-like)
   /circle/partner?email=...&name=...
-------------------------------------------------------------------*/
async function resolvePartnerFromQuery(req) {
  const email = req.query.partner_email || req.query.email;
  const name = req.query.partner_name || req.query.name || 'Circle Partner';

  if (!email) return null;

  let user = (await q('select * from app_user where email=$1', [email])).rows[0];

  if (!user) {
    user = (
      await q(
        `insert into app_user (id,email,full_name,role)
         values ($1,$2,$3,$4)
         returning *`,
        [uuidv4(), email, name, 'PARTNER']
      )
    ).rows[0];

    await q(
      'insert into wallet (user_id,balance,hold_balance) values ($1,$2,$3)',
      [user.id, 0, 0]
    );
  } else if (!user.full_name && name) {
    await q('update app_user set full_name=$1 where id=$2', [name, user.id]);
    user.full_name = name;
  }

  return {
    id: user.id,
    email: user.email,
    full_name: user.full_name,
  };
}

/* ---------- PARTNER PORTAL (multi-tenant, ca la builder) ---------- */
/* ---------- PARTNER PORTAL (Circle) ---------- */
// /circle/partner?email=...&name=...
app.get('/circle/partner', async (req, res) => {
  const currentPartner = await resolvePartnerFromQuery(req);
  if (!currentPartner) {
    return res.status(400).send('Lipsește email-ul (?email=...)');
  }

  // Serviciile lui
  const services = (
    await q(
      'select * from service where partner_id=$1 order by created_at desc',
      [currentPartner.id]
    )
  ).rows;

  // Cererile primite pe serviciile lui
  const requests = (
    await q(
      `select r.*,
              s.title as service_title,
              b.full_name as builder_name,
              b.email     as builder_email
       from service_request r
       join service   s on s.id = r.service_id
       join app_user  b on b.id = r.builder_id
       where r.partner_id=$1
       order by r.created_at desc`,
      [currentPartner.id]
    )
  ).rows;

  res.render('partner-portal', {
    partner: currentPartner,
    services,
    requests,
  });
});


/* ------------------------------------------------------------------
   ROUTES (server-rendered demo)
-------------------------------------------------------------------*/

// Home - browse services
// Home - browse services
app.get('/', async (req, res) => {
  const currentBuilder = null;   // <— nu mai folosim resolveBuilderFromQuery

  const services = (
    await q(
      `select s.*, u.full_name as partner_name
       from service s
       join app_user u on u.id = s.partner_id
       where s.status=$1
       order by s.created_at desc`,
      ['ACTIVE']
    )
  ).rows;

  res.render('browse', { services, currentBuilder });
});

/* ---------- POST SERVICE (partner) ---------- */

// GET form
app.get('/post-service', async (req, res) => {
  // dacă vine din Circle cu ?email / ?partner_email, îl rezolvăm
  const currentPartner = await resolvePartnerFromQuery(req);

  res.render('post-service', {
    message: null,
    currentPartner,
  });
});


// POST form
app.post('/post-service', async (req, res) => {
  const { email, full_name, title, description, price } = req.body;

  let user = (await q('select * from app_user where email=$1', [email])).rows[0];
  if (!user) {
    user = (
      await q(
        'insert into app_user (id,email, full_name, role) values ($1,$2,$3,$4) returning *',
        [uuidv4(), email, full_name || 'Partner', 'PARTNER']
      )
    ).rows[0];
    await q('insert into wallet (user_id,balance,hold_balance) values ($1,0,0)', [
      user.id,
    ]);
  } else if (!user.full_name && full_name) {
    await q('update app_user set full_name=$1 where id=$2', [full_name, user.id]);
    user.full_name = full_name;
  }

  await q(
    'insert into service (id,partner_id, title, description, price, status) values ($1,$2,$3,$4,$5,$6)',
    [uuidv4(), user.id, title, description, parseInt(price) || 0, 'ACTIVE']
  );

  // 🔥 după ce a postat serviciul, îl trimitem direct în profilul lui de partener
  const redirectUrl =
    '/circle/partner?email=' +
    encodeURIComponent(user.email) +
    '&name=' +
    encodeURIComponent(user.full_name || full_name || 'Partner');

  res.redirect(redirectUrl);
});

/* ---------- VIEW SERVICE & CREATE REQUEST (builder) ---------- */

// View service details
app.get('/service/:id', async (req, res) => {
  const id = req.params.id;
  const svc = (
    await q(
      `select s.*, u.email as partner_email, u.full_name as partner_name
       from service s
       join app_user u on u.id = s.partner_id
       where s.id=$1`,
      [id]
    )
  ).rows[0];

  if (!svc) return res.status(404).send('Service not found');

  // deocamdată nu avem user din Circle, deci null
  const currentBuilder = null;

  res.render('service', {
    service: svc,
    message: null,
    currentBuilder,
  });
});

// Create request (builder)
// Create request (builder)
app.post('/service/:id/request', async (req, res) => {
  const svcId = req.params.id;
  const { builder_email, builder_name } = req.body;
  const svc = (await q('select * from service where id=$1', [svcId])).rows[0];
  if (!svc) return res.status(404).send('Service not found');

  // ensure builder user and wallet
  let builder = (await q('select * from app_user where email=$1', [builder_email])).rows[0];
  if (!builder) {
    builder = (
      await q(
        'insert into app_user (id,email, full_name, role) values ($1,$2,$3,$4) returning *',
        [uuidv4(), builder_email, builder_name || 'Builder', 'BUILDER']
      )
    ).rows[0];
    await q(
      'insert into wallet (user_id,balance,hold_balance) values ($1,1000,0)',
      [builder.id]
    ); // demo: give 1000 credits
  } else if (!builder.full_name && builder_name) {
    await q('update app_user set full_name=$1 where id=$2', [builder_name, builder.id]);
    builder.full_name = builder_name;
  }

  const partner = (await q('select * from app_user where id=$1', [svc.partner_id])).rows[0];

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const requestRes = await client.query(
      `insert into service_request (id,service_id, builder_id, partner_id, status, amount)
       values ($1,$2,$3,$4,$5,$6)
       returning *`,
      [uuidv4(), svcId, builder.id, partner.id, 'REQUESTED', svc.price]
    );
    const reqRow = requestRes.rows[0];

    await client.query(
      'insert into ledger_entry (id,request_id, user_id, type, amount) values ($1,$2,$3,$4,$5)',
      [uuidv4(), reqRow.id, builder.id, 'HOLD', svc.price]
    );
    await client.query(
      'update wallet set balance = balance - $1, hold_balance = hold_balance + $1 where user_id=$2',
      [svc.price, builder.id]
    );

    await client.query('COMMIT');

    await notify(
      partner.id,
      'REQUEST_CREATED',
      'Nouă cerere la serviciul tău',
      `Ai primit o cerere la: ${svc.title}`,
      `${FRONTEND_URL || ''}/partner/${encodeURIComponent(partner.email)}/requests`
    );

    // 🚀 redirect direct în profilul builder-ului
    const redirectUrl =
      '/circle/builder?email=' +
      encodeURIComponent(builder.email) +
      '&name=' +
      encodeURIComponent(builder.full_name || builder_name || 'Builder');

    res.redirect(redirectUrl);
  } catch (e) {
    await client.query('ROLLBACK');
    console.error(e);
    res.status(500).send('Error creating request: ' + e.message);
  } finally {
    client.release();
  }
});


/* ---------- PARTENER: Requests list ---------- */

app.get('/partner/:email/requests', async (req, res) => {
  const email = req.params.email;
  const partner = (await q('select * from app_user where email=$1', [email])).rows[0];
  if (!partner) return res.status(404).send('Partner not found');

  const requests = (
    await q(
      `select r.*,
              s.title as service_title,
              b.full_name as builder_name,
              b.email     as builder_email
       from service_request r
       join service   s on s.id = r.service_id
       join app_user  b on b.id = r.builder_id
       where r.partner_id=$1
       order by r.created_at desc`,
      [partner.id]
    )
  ).rows;

  res.render('partner-requests', { partner, requests });
});

// Partner accepts request -> IN_PROGRESS (+ notificare builder)
app.post('/request/:id/accept', async (req, res) => {
  const id = req.params.id;

  // luăm request + email-ul partenerului pentru redirect
  const row = (
    await q(
      `select r.*, u.email as partner_email
       from service_request r
       join app_user u on u.id = r.partner_id
       where r.id = $1`,
      [id]
    )
  ).rows[0];

  if (!row) {
    return res.status(404).send('Request not found');
  }

  await q('update service_request set status=$1 where id=$2', [
    'IN_PROGRESS',
    id,
  ]);

  await notify(
    row.builder_id,
    'REQUEST_ACCEPTED',
    'Cerere acceptată',
    'Partenerul a acceptat cererea ta. Status: IN_PROGRESS.',
    `${FRONTEND_URL || ''}/builder/requests`
  );

  // înapoi la lista de cereri a partenerului
  res.redirect('/partner/' + encodeURIComponent(row.partner_email) + '/requests');
});

// Partner delivers -> DELIVERED (transfer hold -> partner balance) + notificare builder
app.post('/request/:id/deliver', async (req, res) => {
  const id = req.params.id;
  const { delivery_note } = req.body;

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const r = (
      await client.query(
        `select r.*, u.email as partner_email
         from service_request r
         join app_user u on u.id = r.partner_id
         where r.id=$1
         for update`,
        [id]
      )
    ).rows[0];

    if (!r) {
      await client.query('ROLLBACK');
      return res.status(404).send('Request not found');
    }

    // transfer hold -> partner balance
    await client.query(
      'update wallet set hold_balance = hold_balance - $1 where user_id=$2',
      [r.amount, r.builder_id]
    );
    await client.query(
      'update wallet set balance = balance + $1 where user_id=$2',
      [r.amount, r.partner_id]
    );

    await client.query(
      'insert into ledger_entry (id,request_id, user_id, type, amount) values ($1,$2,$3,$4,$5)',
      [uuidv4(), r.id, r.builder_id, 'DEDUCT', r.amount]
    );
    await client.query(
      'insert into ledger_entry (id,request_id, user_id, type, amount) values ($1,$2,$3,$4,$5)',
      [uuidv4(), r.id, r.partner_id, 'CREDIT', r.amount]
    );

    await client.query(
      'update service_request set status=$1, delivered_at=now(), delivery_note=$2 where id=$3',
      ['DELIVERED', delivery_note || null, r.id]
    );

    await client.query('COMMIT');

    await notify(
      r.builder_id,
      'DELIVERED',
      'Serviciu livrat',
      'Partenerul a marcat cererea ca livrată. Lasă un review.',
      `${FRONTEND_URL || ''}/builder/requests`
    );
    await notify(
      r.builder_id,
      'REVIEW_REMINDER',
      'Lasă un review',
      'Ajută comunitatea cu un review pentru serviciul livrat.',
      `${FRONTEND_URL || ''}/builder/requests`
    );

    // AICI era bug-ul – folosim email-ul, nu UUID-ul
    res.redirect('/partner/' + encodeURIComponent(r.partner_email) + '/requests');
  } catch (e) {
    await client.query('ROLLBACK');
    console.error(e);
    res.status(500).send('Error delivering: ' + e.message);
  } finally {
    client.release();
  }
});


// Partner cancels / rejects a request
app.post('/request/:id/cancel', async (req, res) => {
  const id = req.params.id;
  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    // blocăm request-ul și luăm și email-ul partenerului pentru redirect
    const r = (
      await client.query(
        `select r.*, u.email as partner_email
         from service_request r
         join app_user u on u.id = r.partner_id
         where r.id = $1
         for update`,
        [id]
      )
    ).rows[0];

    if (!r) {
      await client.query('ROLLBACK');
      return res.status(404).send('Request not found');
    }

    // 1) mutăm banii din hold_balance înapoi în balance (builder)
    await client.query(
      'update wallet set balance = balance + $1, hold_balance = hold_balance - $1 where user_id = $2',
      [r.amount, r.builder_id]
    );

    // 2) ledger RELEASE pentru builder
    await client.query(
      'insert into ledger_entry (id,request_id,user_id,type,amount) values ($1,$2,$3,$4,$5)',
      [uuidv4(), r.id, r.builder_id, 'RELEASE', r.amount]
    );

    // 3) marcăm cererea ca anulată / respinsă
    await client.query(
      'update service_request set status=$1 where id=$2',
      ['CANCELLED', id]
    );

    await client.query('COMMIT');

    // notificare la builder
    await notify(
      r.builder_id,
      'REQUEST_CANCELLED',
      'Cerere respinsă',
      'Partenerul a respins cererea ta, creditele ți-au fost returnate.',
      `${FRONTEND_URL || ''}/builder/requests`
    );

    // înapoi în dashboard-ul partenerului
    res.redirect('/partner/' + encodeURIComponent(r.partner_email) + '/requests');
  } catch (e) {
    await client.query('ROLLBACK');
    console.error('cancel error:', e);
    res.status(500).send('Cancel failed: ' + e.message);
  } finally {
    client.release();
  }
});

// Builder leaves review
app.post('/request/:id/review', async (req, res) => {
  const id = req.params.id;
  const { rating, comment } = req.body;
  const r = (await q('select * from service_request where id=$1', [id])).rows[0];
  if (!r) return res.status(404).send('Request not found');
  await q(
    'insert into review (id,request_id, builder_id, partner_id, rating, comment, visible) values ($1,$2,$3,$4,$5,$6,$7)',
    [uuidv4(), r.id, r.builder_id, r.partner_id, parseInt(rating) || 5, comment || '', true]
  );
  await q('update service_request set status=$1 where id=$2', ['REVIEWED', r.id]);
  res.send('Review posted (visible=true for demo)');
});

/* ---------- PARTENER: servicii mele (list/create/edit) ---------- */
app.get('/partner/:email/services', async (req, res) => {
  const p = (
    await q('select * from app_user where email=$1 and role=$2', [
      req.params.email,
      'PARTNER',
    ])
  ).rows[0];
  if (!p) return res.status(404).send('Partner not found');
  const services = (
    await q('select * from service where partner_id=$1 order by created_at desc', [p.id])
  ).rows;

  // simplu HTML pentru management rapid (poți cere EJS frumos ulterior)
  res.send(`<!doctype html><meta charset="utf-8"><title>Serviciile mele</title>
    <style>body{font-family:system-ui;margin:20px} table{border-collapse:collapse;width:100%} td,th{border:1px solid #ddd;padding:8px} input,textarea{width:100%;padding:6px}</style>
    <h1>Serviciile mele – ${p.full_name}</h1>
    <p><a href="/">Catalog</a> · <a href="/partner/${encodeURIComponent(p.email)}/requests">Cereri primite</a></p>
    <h2>Adaugă serviciu</h2>
    <form method="post" action="/partner/${encodeURIComponent(p.email)}/services">
      <p><input name="title" placeholder="Titlu" required></p>
      <p><textarea name="description" placeholder="Descriere"></textarea></p>
      <p><input name="price" type="number" placeholder="Preț (credite)" required></p>
      <p><button>Adaugă</button></p>
    </form>
    <h2>Servicii existente</h2>
    <table>
      <tr><th>Titlu</th><th>Preț</th><th>Status</th><th>Actiuni</th></tr>
      ${services
        .map(
          (s) => `
        <tr>
          <td>${s.title}</td>
          <td>${s.price}</td>
          <td>${s.status}</td>
          <td>
            <form method="post" action="/partner/${encodeURIComponent(
              p.email
            )}/services/${s.id}/edit" style="display:inline-block;min-width:360px">
              <input name="title" value="${(s.title || '').replaceAll('"', '&quot;')}" required>
              <input name="price" type="number" value="${s.price}" required>
              <input name="status" value="${s.status}">
              <button>Salvează</button>
            </form>
          </td>
        </tr>`
        )
        .join('')}
    </table>
  `);
});

app.post('/partner/:email/services', async (req, res) => {
  const p = (
    await q('select * from app_user where email=$1 and role=$2', [
      req.params.email,
      'PARTNER',
    ])
  ).rows[0];
  if (!p) return res.status(404).send('Partner not found');
  const { title, description, price } = req.body;
  await q(
    `insert into service(id,partner_id,title,description,price,status)
     values($1,$2,$3,$4,$5,$6)`,
    [uuidv4(), p.id, title, description || '', parseInt(price) || 0, 'ACTIVE']
  );
  res.redirect(`/partner/${encodeURIComponent(p.email)}/services`);
});

app.post('/partner/:email/services/:id/edit', async (req, res) => {
  const p = (
    await q('select * from app_user where email=$1 and role=$2', [
      req.params.email,
      'PARTNER',
    ])
  ).rows[0];
  if (!p) return res.status(404).send('Partner not found');
  const { title, price, status } = req.body;
  await q(
    'update service set title=$1, price=$2, status=$3 where id=$4 and partner_id=$5',
    [title, parseInt(price) || 0, status || 'ACTIVE', req.params.id, p.id]
  );
  res.redirect(`/partner/${encodeURIComponent(p.email)}/services`);
});

/* ---------- BUILDER: cererile mele ---------- */
app.get('/builder/:email/requests', async (req, res) => {
  const b = (
    await q('select * from app_user where email=$1 and role=$2', [
      req.params.email,
      'BUILDER',
    ])
  ).rows[0];
  if (!b) return res.status(404).send('Builder not found');

  const rows = (
    await q(
      `
    select r.*, s.title as service_title, p.full_name as partner_name
    from service_request r
    join service s on s.id=r.service_id
    join app_user p on p.id=r.partner_id
    where r.builder_id=$1
    order by r.created_at desc
  `,
      [b.id]
    )
  ).rows;

  res.send(`<!doctype html><meta charset="utf-8"><title>Cererile mele</title>
    <style>body{font-family:system-ui;margin:20px} input{padding:6px}</style>
    <h1>Cererile mele – ${b.full_name}</h1>
    <p><a href="/">Catalog</a></p>
    ${rows
      .map(
        (r) => `
      <div style="border:1px solid #ddd;padding:12px;margin:10px 0;border-radius:8px">
        <b>${r.service_title}</b> — <i>${r.status}</i> — ${r.amount} cr<br>
        Partener: ${r.partner_name}<br>
        ${
          r.status === 'DELIVERED'
            ? `<form method="post" action="/request/${r.id}/review" style="margin-top:8px">
                <input name="rating" type="number" min="1" max="5" value="5" required>
                <input name="comment" placeholder="Comentariu">
                <button>Trimite review</button>
              </form>`
            : ''
        }
      </div>
    `
      )
      .join('')}
  `);
});

/* ---------- ADMIN: dashboard + acțiuni ---------- */
// Vizualizare (EJS corporatist existent)
app.get('/admin', async (req, res) => {
  const wallets = (
    await q(
      'select w.*, u.email, u.full_name from wallet w join app_user u on u.id = w.user_id'
    )
  ).rows;
  const ledger = (
    await q(
      'select l.*, u.email from ledger_entry l join app_user u on u.id = l.user_id order by l.created_at desc limit 200'
    )
  ).rows;
  res.render('admin', { wallets, ledger });
});

// ADMIN API: List Circle.so users
app.get('/api/admin/list-users', async (req, res) => {
  try {
    const data = await listUsers();
    res.json({ success: true, data });
  } catch (error) {
    console.error('Error listing users:', error);
    res.status(500).json({ success: false, error: error.message });
  }
});

// ADMIN: schimbă status cerere
app.post('/admin/request/:id/status', async (req, res) => {
  const { status } = req.body; // REQUESTED|IN_PROGRESS|DELIVERED|REVIEWED|CANCELLED
  await q('update service_request set status=$1 where id=$2', [
    status,
    req.params.id,
  ]);
  res.redirect('/admin');
});

// ADMIN: editează service
app.post('/admin/service/:id/edit', async (req, res) => {
  const { title, price, status } = req.body;
  await q('update service set title=$1, price=$2, status=$3 where id=$4', [
    title,
    parseInt(price) || 0,
    status || 'ACTIVE',
    req.params.id,
  ]);
  res.redirect('/admin');
});

// ADMIN: ajustare wallet (demo!)
app.post('/admin/wallet/:userId/adjust', async (req, res) => {
  const { balance, hold } = req.body;
  await q('update wallet set balance=$1, hold_balance=$2 where user_id=$3', [
    parseInt(balance) || 0,
    parseInt(hold) || 0,
    req.params.userId,
  ]);
  res.redirect('/admin');
});

/* =================== Circle.so API helpers =================== */

// Configuration - Replace these with your actual values
const CIRCLE_API_TOKEN = process.env.CIRCLE_API_TOKEN || 'your_circle_api_token_here';
const CIRCLE_AUTH_EMAIL = process.env.CIRCLE_AUTH_EMAIL || 'your_email@example.com';

// API URLs
const AUTH_URL = 'https://app.circle.so/api/v1/headless/auth_token';
const MEMBERS_URL = 'https://app.circle.so/api/headless/v1/community_members';
const MEMBER_URL = 'https://app.circle.so/api/headless/v1/community_member';
const UPDATE_URL = 'https://app.circle.so/api/headless/v1/profile';

/**
 * Get Circle.so access token
 * @returns {Promise<string>} Access token
 */
async function getCircleAccessToken() {
  console.log('Attempting to get access token...');

  const authPayload = { email: CIRCLE_AUTH_EMAIL };
  const authHeaders = {
    Authorization: `Bearer ${CIRCLE_API_TOKEN}`,
    'Content-Type': 'application/json',
  };

  try {
    const response = await fetch(AUTH_URL, {
      method: 'POST',
      headers: authHeaders,
      body: JSON.stringify(authPayload),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`HTTP error during auth: ${errorText}`);
      throw new Error(`Error from Circle auth API: ${errorText}`);
    }

    const data = await response.json();
    const accessToken = data.access_token;

    if (!accessToken) {
      console.error("Error: 'access_token' not found in auth response.");
      throw new Error("Could not retrieve 'access_token' from Circle.");
    }

    console.log('Successfully retrieved access token.');
    return accessToken;
  } catch (error) {
    console.error(`An unexpected error occurred during auth: ${error.message}`);
    throw error;
  }
}

/**
 * List all community members
 * @returns {Promise<Object>} Members data
 */
async function listUsers() {
  try {
    const accessToken = await getCircleAccessToken();

    console.log(`Using access token to fetch members from ${MEMBERS_URL}...`);
    const membersHeaders = {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    };

    const response = await fetch(MEMBERS_URL, {
      method: 'GET',
      headers: membersHeaders,
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`HTTP error during member fetch: ${errorText}`);
      throw new Error(`Error from Circle members API: ${errorText}`);
    }

    console.log('Successfully retrieved members data.');
    const responseData = await response.json();
    const membersList = responseData.records;

    if (!membersList) {
      console.error("Error: 'records' key not found in API response.");
      throw new Error("'records' key not found in API response");
    }

    console.log(`\n--- Iterating over ${membersList.length} members ---`);

    membersList.forEach((member) => {
      const memberId = member.community_member_id;
      const memberName = member.name || 'N/A';
      const memberEmail = member.email || 'N/A';

      console.log(
        `Processing Member ID: ${memberId}, Name: ${memberName}, Email: ${memberEmail}`
      );
    });

    console.log(`--- Finished iterating over ${membersList.length} members ---\n`);
    console.log('Members data:', JSON.stringify(membersList, null, 2));

    return responseData;
  } catch (error) {
    console.error(`An unexpected error occurred during member fetch: ${error.message}`);
    throw error;
  }
}

/**
 * Get current user data
 * @returns {Promise<Object>} User data
 */
async function getUser() {
  try {
    const accessToken = await getCircleAccessToken();

    const memberHeaders = {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    };

    const response = await fetch(MEMBER_URL, {
      method: 'GET',
      headers: memberHeaders,
    });

    if (!response.ok) {
      const errorText = await response.text();
      if (response.status === 404) {
        console.error('User not found.');
        throw new Error('User not found');
      }
      console.error(`HTTP error during user fetch: ${errorText}`);
      throw new Error(`Error from Circle API: ${errorText}`);
    }

    console.log('Successfully retrieved user data');
    const userData = await response.json();

    const memberName = userData.name || 'N/A';
    const memberEmail = userData.email || 'N/A';
    const userId = userData.id || 'N/A';
    console.log(`User Details - ID: ${userId}, Name: ${memberName}, Email: ${memberEmail}`);

    return userData;
  } catch (error) {
    console.error(`An unexpected error occurred during user fetch: ${error.message}`);
    throw error;
  }
}

/**
 * Update user profile
 * @param {Object} modifications - Object containing profile updates
 * @returns {Promise<Object>} Updated user data
 */
async function updateUser(modifications = null) {
  try {
    const accessToken = await getCircleAccessToken();

    const clientHeaders = {
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    };

    const defaultModifications = {
      community_member: {
        time_zone: 'UTC',
        avatar_url: 'https://example.com/avatar.png',
        last_name: 'Test',
      },
    };

    const updatePayload = modifications || defaultModifications;

    const response = await fetch(UPDATE_URL, {
      method: 'PUT',
      headers: clientHeaders,
      body: JSON.stringify(updatePayload),
    });

    if (!response.ok) {
      const errorText = await response.text();
      if (response.status === 404) {
        console.error('Bad token or user not found');
        throw new Error('User not found');
      }
      console.error(`HTTP error during user update: ${errorText}`);
      throw new Error(`Error from Circle API: ${errorText}`);
    }

    console.log('Successfully updated client details');
    const userData = await response.json();

    return userData;
  } catch (error) {
    console.error(`An unexpected error occurred during user update: ${error.message}`);
    throw error;
  }
}

// Exemplu de handlers dacă vrei să le chemi din front (momentan sunt doar pentru debug în Node)
async function handleListUsers() {
  try {
    const data = await listUsers();
    console.log('Members:', data);
  } catch (error) {
    console.error('Error:', error.message);
  }
}

async function handleGetUser() {
  try {
    const data = await getUser();
    console.log('User:', data);
  } catch (error) {
    console.error('Error:', error.message);
  }
}

async function handleUpdateUser() {
  try {
    const modifications = {
      community_member: {
        time_zone: 'America/New_York',
        last_name: 'Updated',
      },
    };
    const data = await updateUser(modifications);
    console.log('Updated user:', data);
  } catch (error) {
    console.error('Error:', error.message);
  }
}

/* ===================== ADMIN — DANGER / MAINTENANCE ===================== */

// ȘTERGE un request (șterge și ledger+review aferente)
app.post('/admin/request/:id/delete', async (req, res) => {
  const id = req.params.id;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    await client.query('delete from ledger_entry where request_id=$1', [id]);
    await client.query('delete from review where request_id=$1', [id]);
    await client.query('delete from service_request where id=$1', [id]);

    await client.query('COMMIT');
    res.redirect('/admin');
  } catch (e) {
    await client.query('ROLLBACK');
    console.error('admin delete request error:', e);
    res.status(500).send('Delete request failed: ' + e.message);
  } finally {
    client.release();
  }
});

// ȘTERGE un service (cascade manual la cereri, ledger, review)
app.post('/admin/service/:id/delete', async (req, res) => {
  const id = req.params.id;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const reqs = (
      await client.query('select id from service_request where service_id=$1', [id])
    ).rows;
    const reqIds = reqs.map((r) => r.id);

    if (reqIds.length) {
      await client.query('delete from ledger_entry where request_id = any($1)', [reqIds]);
      await client.query('delete from review where request_id = any($1)', [reqIds]);
      await client.query('delete from service_request where id = any($1)', [reqIds]);
    }

    await client.query('delete from service where id=$1', [id]);

    await client.query('COMMIT');
    res.redirect('/admin');
  } catch (e) {
    await client.query('ROLLBACK');
    console.error('admin delete service error:', e);
    res.status(500).send('Delete service failed: ' + e.message);
  } finally {
    client.release();
  }
});

// ȘTERGE un ledger entry punctual
app.post('/admin/ledger/:id/delete', async (req, res) => {
  try {
    await q('delete from ledger_entry where id=$1', [req.params.id]);
    res.redirect('/admin');
  } catch (e) {
    console.error('admin delete ledger error:', e);
    res.status(500).send('Delete ledger failed: ' + e.message);
  }
});

// ȘTERGE un utilizator complet (cu toate datele aferente)
app.post('/admin/user/:userId/delete', async (req, res) => {
  const userId = req.params.userId;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    // cereri în care userul e builder sau partner
    const reqs = (
      await client.query(
        `select id from service_request where builder_id=$1 or partner_id=$1`,
        [userId]
      )
    ).rows;
    const reqIds = reqs.map((r) => r.id);

    if (reqIds.length) {
      await client.query('delete from ledger_entry where request_id = any($1)', [
        reqIds,
      ]);
      await client.query('delete from review where request_id = any($1)', [reqIds]);
      await client.query('delete from service_request where id = any($1)', [reqIds]);
    }

    // servicii create de user ca PARTNER
    const services = (
      await client.query(`select id from service where partner_id=$1`, [userId])
    ).rows.map((r) => r.id);
    if (services.length) {
      await client.query('delete from service where id = any($1)', [services]);
    }

    // orfan ledger pe user_id (dacă există)
    await client.query('delete from ledger_entry where user_id=$1', [userId]);

    // review direct pe user (defensiv, deja curățate prin request_id)
    await client.query(
      'delete from review where builder_id=$1 or partner_id=$1',
      [userId]
    );

    // relații primary/secondary
    await client.query(
      'delete from builder_member where primary_user_id=$1 or member_user_id=$1',
      [userId]
    );

    // notificări + wallet
    await client.query('delete from notification where user_id=$1', [userId]);
    await client.query('delete from wallet where user_id=$1', [userId]);

    // în final userul
    await client.query('delete from app_user where id=$1', [userId]);

    await client.query('COMMIT');
    res.redirect('/admin');
  } catch (e) {
    await client.query('ROLLBACK');
    console.error('admin delete user error:', e);
    res.status(500).send('Delete user failed: ' + e.message);
  } finally {
    client.release();
  }
});

// „NUKE” — golește tot (atenție: ireversibil!)
app.post('/admin/nuke', async (req, res) => {
  const { confirm } = req.body;
  if (confirm !== 'DELETE ALL') {
    return res.status(400).send('Type exactly: DELETE ALL');
  }
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    await client.query(`TRUNCATE TABLE
      review,
      ledger_entry,
      notification,
      service_request,
      service,
      wallet,
      builder_member,
      app_user
      RESTART IDENTITY CASCADE
    `);
    await client.query('COMMIT');
    res.redirect('/admin');
  } catch (e) {
    await client.query('ROLLBACK');
    console.error('admin nuke error:', e);
    res.status(500).send('Nuke failed: ' + e.message);
  } finally {
    client.release();
  }
});

/* ------------------------------------------------------------------
   START SERVER
-------------------------------------------------------------------*/

app.listen(PORT, () => {
  console.log('Server running on port', PORT);
});
// DASHBOARD BUILDER – multi-tenant pe baza email-ului din Circle
app.get('/circle/builder', async (req, res) => {
  // de la Circle (în prod) sau manual local: ?email=...&name=...
  const builder = await resolveUserFromCircleQuery(req, 'BUILDER');
  if (!builder) {
    return res.status(400).send('Lipsește email-ul (?email=...)');
  }

  const requests = (
    await q(
      `
      select r.*,
             s.title     as service_title,
             p.full_name as partner_name,
             p.email     as partner_email
      from service_request r
      join service   s on s.id = r.service_id
      join app_user  p on p.id = r.partner_id
      where r.builder_id = $1
      order by r.created_at desc
    `,
      [builder.id]
    )
  ).rows;

  res.render('builder-portal', {
    builder,
    requests,
  });
});
